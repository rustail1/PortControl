const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { mkdtempSync } = require('node:fs');
const { tmpdir } = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');
const { buildViteLaunch, terminateOwnedProcess } = require('./browser-runner.cjs');

const url = 'http://127.0.0.1:4181';
const artifacts = mkdtempSync(path.join(tmpdir(), 'port-control-redraw-'));
const css = (snapshot, point) => ({
  x: Math.round(snapshot.worldViewportCss.x + point.x * snapshot.worldViewportCss.width / 1000),
  y: Math.round(snapshot.worldViewportCss.y + point.y * snapshot.worldViewportCss.height / 1000),
});

function distanceToSegment(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = dx * dx + dy * dy;
  if (lengthSquared === 0) return Math.hypot(point.x - start.x, point.y - start.y);
  const t = Math.max(0, Math.min(1,
    ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared));
  return Math.hypot(point.x - start.x - dx * t, point.y - start.y - dy * t);
}

function assertStableFixedBends(previousEnds, currentEnds, previousBody, currentBody) {
  const previousFixed = previousEnds.slice(0, -1);
  const currentFixed = currentEnds.slice(0, -1);
  if (previousFixed.length === 0 || currentFixed.length === 0) return;

  // Find the largest exact overlap between the surviving suffix of the old fixed
  // geometry and the prefix of the new fixed geometry. Only a consumed prefix may vanish.
  let overlap = Math.min(previousFixed.length, currentFixed.length);
  for (; overlap > 0; overlap -= 1) {
    const oldSuffix = previousFixed.slice(previousFixed.length - overlap);
    const newPrefix = currentFixed.slice(0, overlap);
    if (JSON.stringify(oldSuffix) === JSON.stringify(newPrefix)) break;
  }
  const consumedBetweenFrames = overlap === 0 && previousBody !== undefined &&
    previousFixed.every(point => distanceToSegment(point, previousBody, currentBody) <= 2);
  assert.ok(overlap > 0 || consumedBetweenFrames,
    `extending the curve may clip only a consumed prefix, never relocate fixed bends: ${JSON.stringify({ previousFixed, currentFixed })}`);
}

async function main() {
  const launch = buildViteLaunch({ host: '127.0.0.1', port: 4181 });
  const server = spawn(launch.command, launch.args, {
    stdio: ['ignore', 'pipe', 'pipe'], detached: launch.detached, windowsHide: true,
  });
  let browser;
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Vite startup timed out')), 20000);
      server.once('error', reject);
      server.stdout.on('data', chunk => {
        if (String(chunk).includes('4181')) { clearTimeout(timer); resolve(); }
      });
    });
    browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({ viewport: { width: 1000, height: 1000 } });
    const errors = [];
    page.on('pageerror', error => errors.push(String(error)));
    await page.addInitScript(() => {
      crypto.getRandomValues = values => { values[0] = 3333; return values; };
    });
    await page.goto(`${url}/?level=calm_01`, { waitUntil: 'networkidle' });
    await page.waitForFunction(() => globalThis.__PORT_CONTROL_SMOKE__?.getSnapshot()
      ?.ships.some(ship => ship.state === 'Entering' && ship.position.x < 900), null,
    { timeout: 15000 });
    // Capture the real scene through the existing read-only smoke method; no gameplay injection.
    await page.evaluate(async () => {
      const { HarborScene } = await import('/src/scenes/HarborScene.ts');
      const original = HarborScene.prototype.browserSmokeSnapshot;
      HarborScene.prototype.browserSmokeSnapshot = function () {
        globalThis.__REDRAW_SCENE__ = this;
        return original.call(this);
      };
      try { globalThis.__PORT_CONTROL_SMOKE__.getSnapshot(); }
      finally { HarborScene.prototype.browserSmokeSnapshot = original; }
      window.dispatchEvent(new Event('focus'));
      globalThis.__REDRAW_SCENE__.game.loop.sleep();
    });
    const snapshot = () => page.evaluate(() => globalThis.__PORT_CONTROL_SMOKE__.getSnapshot());
    // Pause only the renderer scheduler between assertions. Blur would cancel the draft.
    // The actual Phaser loop and fixed-step simulation run normally during advance().
    const advance = milliseconds => page.evaluate(milliseconds => new Promise((resolve, reject) => {
      const loop = globalThis.__REDRAW_SCENE__.game.loop;
      const target = globalThis.__PORT_CONTROL_SMOKE__.getSnapshot().simulationTime + milliseconds / 1000;
      const timeout = setTimeout(() => { loop.sleep(); reject(new Error('simulation did not advance')); }, 10000);
      loop.wake();
      const check = () => {
        if (globalThis.__PORT_CONTROL_SMOKE__.getSnapshot().simulationTime >= target) {
          loop.sleep();
          clearTimeout(timeout);
          resolve();
        } else requestAnimationFrame(check);
      };
      requestAnimationFrame(check);
    }), milliseconds);
    const move = async (x, y, options) => {
      await page.mouse.move(x, y, options);
      await advance(20);
    };
    const down = async () => { await page.mouse.down(); await advance(20); };
    let state = await snapshot();
    const shipId = state.ships[0].id;
    let start = css(state, state.ships[0].position);
    await move(start.x, start.y);
    await down();
    const pressed = await snapshot();
    await move(150, start.y, { steps: 5 });
    const drawn = await snapshot();
    await page.mouse.up();
    await advance(50);
    state = await snapshot();
    const oldRoute = state.ships.find(ship => ship.id === shipId).route;
    assert.ok(oldRoute, `initial route missing: ${JSON.stringify({ ship: state.ships[0],
      pressed: pressed.activeDraft, drawn: drawn.activeDraft,
      times: [pressed.simulationTime, drawn.simulationTime, state.simulationTime],
      loop: await page.evaluate(() => ({ hidden: document.hidden,
        paused: globalThis.__REDRAW_SCENE__.game.isPaused,
        running: globalThis.__REDRAW_SCENE__.game.loop.running,
        frame: globalThis.__REDRAW_SCENE__.game.loop.frame })) })}`);
    start = css(state, state.ships.find(ship => ship.id === shipId).position);
    start.x += 12; // A normal off-centre grab must not create a false corner.
    await move(start.x, start.y);
    await down();
    await move(start.x, start.y - 30, { steps: 2 });
    await move(start.x, start.y - 140, { steps: 4 });
    const beforeMovement = (await snapshot()).ships.find(ship => ship.id === shipId).position;
    await advance(600);
    const afterMovement = (await snapshot()).ships.find(ship => ship.id === shipId).position;
    assert.ok(Math.hypot(afterMovement.x - beforeMovement.x, afterMovement.y - beforeMovement.y) > 1,
      'vessel must resume naturally while activated live redraw is held');
    await page.screenshot({ path: path.join(artifacts, 'redraw.png') });
    const readVisible = () => page.evaluate(shipId => {
      const objects = globalThis.__REDRAW_SCENE__.children.list;
      const draft = objects.find(object => object.type === 'Graphics' &&
        object.commandBuffer.includes(0xfff0a6));
      const oldRoutes = objects.filter(object => object.type === 'Graphics' &&
        object.depth === 5 && object.visible && object.commandBuffer.length > 0);
      const selected = globalThis.__PORT_CONTROL_SMOKE__.getSnapshot().ships.find(ship => ship.id === shipId);
      const distanceToShip = body => Math.hypot(body.x - selected.position.x, body.y - selected.position.y);
      const body = objects.filter(object => object.type === 'Graphics' && object.depth === 10 &&
        object.alpha === 1).sort((left, right) => distanceToShip(left) - distanceToShip(right))[0];
      const ends = [];
      const buffer = draft?.commandBuffer ?? [];
      const sizes = { 1: 1, 2: 1, 4: 3, 5: 3, 6: 4, 7: 3, 8: 1, 9: 1 };
      let anchor;
      for (let i = 0; i < buffer.length; i += sizes[buffer[i]] ?? buffer.length) {
        if (buffer[i] === 5) anchor = { x: buffer[i + 1], y: buffer[i + 2] };
        if (buffer[i] === 4) ends.push({ x: buffer[i + 1], y: buffer[i + 2] });
      }
      return { oldRoutes: oldRoutes.length, draftDepth: draft?.depth, bodyDepth: body?.depth,
        anchor, body: { x: body.x, y: body.y }, ends,
        bodyHeading: body.rotation * 180 / Math.PI, targetHeading: selected.rotationDeg };
    }, shipId);
    const visible = await readVisible();
    console.log(JSON.stringify({ artifacts, visible }));
    assert.equal(visible.oldRoutes, 0, 'old committed line must hide while replacement is drawn');
    assert.ok(visible.draftDepth < visible.bodyDepth, 'draft must emerge from hull, not draw over it');
    assert.deepEqual(visible.anchor, visible.body, 'preview must start at the actually rendered vessel');
    assert.ok(visible.ends.length >= 1, 'straight swipe must render a visible route');
    const straightTip = visible.ends.at(-1);
    const straightDx = straightTip.x - visible.anchor.x;
    const straightDy = straightTip.y - visible.anchor.y;
    const straightLength = Math.hypot(straightDx, straightDy);
    assert.ok(straightLength > 0, 'straight swipe tip must differ from the rendered vessel');
    for (const point of visible.ends.slice(0, -1)) {
      const perpendicularDistance = Math.abs(
        straightDx * (point.y - visible.anchor.y) -
        straightDy * (point.x - visible.anchor.x),
      ) / straightLength;
      assert.ok(perpendicularDistance <= 0.5,
        `straight swipe must not retain a geometric corner: ${JSON.stringify({ visible, point, perpendicularDistance })}`);
    }
    const activeRoute = (await snapshot()).ships.find(ship => ship.id === shipId).route;
    assert.ok(activeRoute, 'activated redraw must install a live replacement route while pointer is held');
    assert.notDeepEqual(activeRoute, oldRoute, 'activated redraw must stop navigating the old committed route');
    const visibleSuffixStart = activeRoute.points.findIndex(point =>
      point.x === visible.ends[0].x && point.y === visible.ends[0].y);
    assert.ok(visibleSuffixStart >= 0, 'browser preview must begin at an authored future point');
    assert.deepEqual(visible.ends, activeRoute.points.slice(visibleSuffixStart),
      'browser preview may consume only a prefix of the exact authored route');
    assert.deepEqual(activeRoute.points.at(-1), straightTip,
      'active live replacement route must end at the visible drawn tip');
    await page.keyboard.press('Escape');
    await page.mouse.up();
    await advance(20);
    const sealed = (await snapshot()).ships.find(ship => ship.id === shipId).route;
    assert.ok(sealed, 'Escape after an activated redraw must keep the sealed replacement route');
    assert.deepEqual(sealed, activeRoute, 'Escape after an activated redraw must preserve the active live route');
    assert.notDeepEqual(sealed, oldRoute, 'Escape after an activated redraw must not roll back to old route');
    assert.deepEqual(sealed.points.at(-1), straightTip, 'sealed redraw must end at the visible drawn tip');

    // Hold the pointer while the ship moves on its previous route. The new route must
    // start from the ship pose at threshold activation, never the older pointer-down pose.
    state = await snapshot();
    start = css(state, state.ships.find(ship => ship.id === shipId).position);
    await move(start.x, start.y);
    await down();
    await advance(250);
    const activationPose = (await snapshot()).ships.find(ship => ship.id === shipId).position;
    await move(start.x, start.y - 140, { steps: 6 });
    const liveBeforeRelease = (await snapshot()).ships.find(ship => ship.id === shipId).route;
    assert.ok(liveBeforeRelease, 'threshold activation must install the replacement route');
    assert.deepEqual(liveBeforeRelease.start, activationPose,
      'live route must start from activation pose instead of snapping back to pointerdown');
    await advance(600);
    await page.mouse.up();
    await advance(20);
    const committed = (await snapshot()).ships.find(ship => ship.id === shipId).route;
    const committedTip = { x: activationPose.x, y: activationPose.y - 140 };
    assert.ok(committed.points.length >= 1, 'committed straight redraw must contain a route point');
    assert.deepEqual(committed.points.at(-1), committedTip, 'committed route must end at the drawn tip');
    assert.deepEqual(committed.start, liveBeforeRelease.start,
      'release must seal the active route without rebasing its already-followed prefix');
    const committedDx = committedTip.x - committed.start.x;
    const committedDy = committedTip.y - committed.start.y;
    const committedLength = Math.hypot(committedDx, committedDy);
    assert.ok(committedLength > 0, 'committed straight redraw must have non-zero length');
    for (const point of committed.points.slice(0, -1)) {
      const perpendicularDistance = Math.abs(
        committedDx * (point.y - committed.start.y) -
        committedDy * (point.x - committed.start.x),
      ) / committedLength;
      assert.ok(perpendicularDistance <= 0.5,
        `committed straight redraw must not retain a geometric corner: ${JSON.stringify({ committed, point, perpendicularDistance })}`);
    }
    assert.deepEqual(committed.points, liveBeforeRelease.points,
      'release must preserve the exact authored live geometry');
    const angleError = pose => Math.abs(((pose.bodyHeading - pose.targetHeading) % 360 + 540) % 360 - 180);
    assert.ok(angleError(await readVisible()) < 5,
      'rendered hull must track the already turn-rate-limited simulation heading without a second lag');
    await advance(600);
    assert.ok(angleError(await readVisible()) < 5, 'visual hull must stay aligned with authoritative heading');

    state = await snapshot();
    start = css(state, state.ships.find(ship => ship.id === shipId).position);
    await move(start.x, start.y);
    await down();
    const curveStart = (await snapshot()).ships.find(ship => ship.id === shipId).position;
    let previousEnds = [];
    let previousBody;
    for (let i = 1; i <= 12; i++) {
      const angle = i * Math.PI / 24;
      await move(Math.round(start.x - 180 * Math.sin(angle)), Math.round(start.y + 180 * (1 - Math.cos(angle))));
      const pose = await readVisible();
      assert.deepEqual(pose.anchor, pose.body, 'moving curve must stay attached to the rendered hull');
      assertStableFixedBends(previousEnds, pose.ends, previousBody, pose.body);
      previousEnds = pose.ends;
      previousBody = pose.body;
    }
    assert.ok(previousEnds.length > 2);
    const curveEnd = (await snapshot()).ships.find(ship => ship.id === shipId).position;
    assert.ok(Math.hypot(curveEnd.x - curveStart.x, curveEnd.y - curveStart.y) > 20);
    await page.keyboard.press('Escape');
    await page.mouse.up();
    assert.deepEqual(errors, []);
    console.log('Redraw browser: PASS (no start snap, no double heading lag, moving straight/curved swipe, stable bends)');
  } finally {
    try { await browser?.close(); }
    finally { await terminateOwnedProcess(server); }
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
