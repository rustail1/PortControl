# Port Control project map

Targeted navigation map for Codex. Start here, then use `rg` on the named area.

## Entrypoints and runtime

- App entry: `src/main.ts`
- Bootstrap scene: `src/scenes/BootstrapScene.ts`
- Main Phaser scene: `src/scenes/HarborScene.ts`
- Level query selection: `src/scenes/HarborLevelSelection.ts`
- Runtime composition/fixed-step order: `src/runtime/HarborRuntime.ts`
- Runtime/browser integration tests: `test/cor12-*.test.mjs`
- Browser smoke: `test/browser/cor12-smoke.cjs`

## Routes and input

- Pointer gesture ownership: `src/routes/RouteInputController.ts`
- Route commit authority: `src/routes/RouteCommitService.ts`
- Navigation validation: `src/routes/NavigationValidator.ts`
- Sampling constants: `src/routes/RouteSamplingConfig.ts`
- Simplification: `src/routes/RouteSimplifier.ts`
- Processing constants: `src/routes/RouteProcessingConfig.ts`
- Public exports: `src/routes/index.ts`
- Core tests: `test/cor02-route-input.test.mjs`, `test/cor03-route-pipeline.test.mjs`

## Ships and movement

- Authoritative ship state: `src/ships/ShipModel.ts`
- Immutable route/progress: `src/ships/ShipRoute.ts`
- Fixed-step follower: `src/ships/ShipMotor.ts`
- State enum/traffic classification: `src/ships/ShipState.ts`
- Characteristics from config: `src/ships/ShipCharacteristics.ts`
- Public exports: `src/ships/index.ts`
- Tests: `test/cor01-ship-domain.test.mjs`, `test/cor03-route-pipeline.test.mjs`

## Docks and cargo

- Dock ownership/compatibility: `src/docks/DockSystem.ts`
- Dock model: `src/docks/DockModel.ts`
- Dock factory: `src/docks/DockFactory.ts`
- Docking transition/motion: `src/docks/DockingController.ts`
- Docking config adapter: `src/docks/DockingConfig.ts`
- Unloading transactions: `src/docks/CargoSystem.ts`
- Tests: `test/cor04-docks.test.mjs`, `test/cor05-docking.test.mjs`, `test/cor06-cargo.test.mjs`

## Spawning and incoming flow

- Spawn schedule/pressure/cargo RNG: `src/spawning/SpawnDirector.ts`
- Pre-materialization flow: `src/spawning/IncomingSpawnSystem.ts`
- Materialization: `src/spawning/ShipSpawner.ts`
- Spawn point model/factory: `src/spawning/SpawnPoint.ts`, `src/spawning/SpawnPointFactory.ts`
- Weighted choice: `src/spawning/WeightedSpawnPointPicker.ts`
- Tests: `test/cor09-spawn.test.mjs`, `test/cor10-spawn-director.test.mjs`

## Exit and presentation flow

- Authoritative ExitZone resolution: `src/exits/ExitSystem.ts`
- Incoming/departure presentation: `src/presentation/VesselFlowPresentation.ts`
- Short visual pulses: `src/presentation/PresentationPulseStore.ts`
- HUD layout: `src/presentation/HarborUiLayout.ts`
- Scene rendering: `src/scenes/HarborScene.ts`
- Tests: `test/cor07-exit.test.mjs`, `test/cor12-fix2b.test.mjs`, `test/cor12-fix3.test.mjs`

## Collision and grounding

- Ship collision/danger facts: `src/collision/CollisionSystem.ts`
- Shore geometry helpers: `src/geometry/LandClearanceGeometry.ts`
- Grounding resolution: `src/grounding/GroundingSystem.ts`
- Tests: `test/cor08-collision.test.mjs`, relevant `test/cor12-*.test.mjs`

## Session, objectives, score

- Session orchestration: `src/core/GameSession.ts`
- Session state: `src/core/SessionState.ts`
- Fixed-step clock: `src/core/FixedStepClock.ts`
- Seeded randomness: `src/core/SeededRng.ts`
- Domain event ordering: `src/core/DomainEventQueue.ts`
- Objective state: `src/objectives/ObjectiveSystem.ts`
- Score rules: `src/objectives/ScoreService.ts`
- Metrics: `src/objectives/SessionMetrics.ts`
- Stars: `src/objectives/StarEvaluator.ts`
- Tests: `test/cor11-session.test.mjs`, `test/deterministic-core.test.mjs`

## Config and validation

- Bundled loader: `src/config/loadBundledConfig.ts`
- Runtime config types: `src/config/types.ts`
- JSON Schema validation: `src/config/schemaValidation.ts`
- Semantic validation: `src/config/semanticValidation.ts`
- Geometry validation: `src/config/geometryValidation.ts`
- Machine-contract IDs: `src/config/MachineContractIdRegistry.ts`
- Frozen source: `Port_Control_Baseline_Source_FINAL_v1.5/`
- Config tests: `test/config-validation.test.mjs`, `test/fnd07-machine-contracts.test.mjs`

## Platform, camera and debug

- Platform boundary: `src/platform/IPlatformAdapter.ts`
- Local implementation: `src/platform/LocalPlatformAdapter.ts`
- Logical square viewport: `src/camera/SquareWorldViewport.ts`
- Debug overlay: `src/debug/DebugOverlay.ts`
- Tests: `test/local-platform-adapter.test.mjs`, `test/responsive-logical-world.test.mjs`

## Commands

- Dev/HMR: `npm.cmd run dev`
- Unit/config suite: `npm.cmd test`
- Typecheck: `npm.cmd run typecheck`
- Production build: `npm.cmd run build`
- Browser gate: `npm.cmd run test:browser`
- VS Code full gate: `Tasks: Run Task -> Port Control: full gate`
- Human feel: F5 `Port Control: calm_01`; `calm_07` is the island regression launch.

## Frozen validators

Run from `Port_Control_Baseline_Source_FINAL_v1.5/` with UTF-8:

- `python -X utf8 tools/validate_baseline.py .`
- `python -X utf8 tools/validate_localization.py .`
- `python -X utf8 tools/semantic_roundtrip.py .`
- `python -X utf8 tools/validate_assets.py .`

## Git boundaries

- Active delivery branch: `main`, unless the task explicitly says otherwise.
- Local `.vscode/`, `AGENTS.md`, and `PROJECT_MAP.md` are excluded in `.git/info/exclude`.
- Keep `VALIDATION_REPORT.txt`, caches, and unrelated dirty files out of commits.
- Before delivery: exact file list, `git diff --check`, requested gates, explicit commit/push/CI only.
